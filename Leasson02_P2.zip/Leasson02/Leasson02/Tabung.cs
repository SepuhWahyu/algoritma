﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Tabung
    {
        private double jariJari;
        private double tinggi;

        public Tabung(double j, double t)
        {
            jariJari = j;
            tinggi = t;
        }

        public double VolumeTabung()
        {
            double phi = 3.14;
            double Rsqrt = jariJari * jariJari;

            return phi * Rsqrt * tinggi;
        }
    }
}
