﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DataTable Table;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Table = new DataTable();
            Table.Columns.Add("Kode", typeof(string));
            Table.Columns.Add("Nama", typeof(string));
            Table.Columns.Add("Jumlah", typeof(string));

            dataGridView1.DataSource = Table;
            dataGridView1.Columns["kode"].Width = 99;
            dataGridView1.Columns["Nama"].Width = 99;
            dataGridView1.Columns["Jumlah"].Width = 99;
        }

        private void SimpanBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (KodeInput.Text == "")
                {
                    LabelMsg.Text = "Kode tidak boleh kosong";
                    return;
                }

                int kode = Convert.ToInt32(KodeInput.Text);
                if (kode < 1)
                {
                    LabelMsg.Text = "Kode tidak boleh kurang dari 1";
                    return;
                }
                else if (kode > 999999)
                {
                    LabelMsg.Text = "Kode tidak boleh lebih dari 999999";
                    return;
                }
            }
            catch (Exception)
            {
                LabelMsg.Text = "Kode harus berupa angka";
                return;
            }

            if (NamaInput.Text == "")
            {
                LabelMsg.Text = "Nama tidak boleh kosong";
                return;
            }

            if(JumlahInput.Text == "")
            {
                JumlahInput.Text = "0";
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (KodeInput.Text == Table.Rows[i].ItemArray[0].ToString())
                {
                    LabelMsg.Text = "Kode sudah digunakan";
                    return;
                }
            }

            Table.Rows.Add(KodeInput.Text, NamaInput.Text, JumlahInput.Text);

            LabelMsg.Text = "";
            LabelMsg.Text = "";

            KodeInput.Clear();
            NamaInput.Clear();
            JumlahInput.Clear();
        }

        private void CariBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (KodeInput.Text == "")
                {
                    LabelMsg.Text = "Kode tidak boleh kosong";
                    return;
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    LabelMsg.Text= "Silahkan tambahkan data terlebih dahulu";
                    return;
                }

                int kode = Convert.ToInt32(KodeInput.Text);
                if (kode < 1)
                {
                    LabelMsg.Text = "Kode tidak boleh kurang dari 1";
                    return;
                }
                else if (kode > 999999)
                {
                    LabelMsg.Text = "Kode tidak boleh lebih dari 999999";
                    return;
                }
            }
            catch (Exception)
            {
                LabelMsg.Text = "Kode harus berupa angka";
                return;
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                Console.WriteLine(i);
                LabelMsg.Text = "";

                if (KodeInput.Text == Table.Rows[i].ItemArray[0].ToString())
                {
                    KodeInput.Text = Table.Rows[i].ItemArray[0].ToString();
                    NamaInput.Text = Table.Rows[i].ItemArray[1].ToString();
                    JumlahInput.Text = Table.Rows[i].ItemArray[2].ToString();
                    return;
                }
                else
                {
                    LabelMsg.Text = "Kode tidak ditemukan";
                }
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (KodeInput.Text == "")
                {
                    LabelMsg.Text = "Kode tidak boleh kosong";
                    return;
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    LabelMsg.Text = "Silahkan tambahkan data terlebih dahulu";
                    return;
                }

                int kode = Convert.ToInt32(KodeInput.Text);
                if (kode < 1)
                {
                    LabelMsg.Text = "Kode tidak boleh kurang dari 1";
                    return;
                }
                else if (kode > 999999)
                {
                    LabelMsg.Text = "Kode tidak boleh lebih dari 999999";
                    return;
                }
            }
            catch (Exception)
            {
                LabelMsg.Text = "Kode harus berupa angka";
                return;
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                LabelMsg.Text = "";

                if (KodeInput.Text == Table.Rows[i].ItemArray[0].ToString())
                {
                    Table.Rows[i].Delete();
                    Table.Rows.Add(KodeInput.Text, NamaInput.Text, JumlahInput.Text);
                    return;
                }
            }
            LabelMsg.Text = ("Tolong cari data terlebih dahulu sebelum di edit");
        }

        private void HapusBtn_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;

            Table.Rows[index].Delete();
        }

        private void LabelMsg_Click(object sender, EventArgs e)
        {

        }
    }
}
