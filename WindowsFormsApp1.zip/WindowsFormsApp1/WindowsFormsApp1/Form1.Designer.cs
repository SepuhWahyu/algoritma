﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SimpanBtn = new System.Windows.Forms.Button();
            this.Judul = new System.Windows.Forms.Label();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.KodeInput = new System.Windows.Forms.TextBox();
            this.NamaInput = new System.Windows.Forms.TextBox();
            this.JumlahInput = new System.Windows.Forms.TextBox();
            this.EditBtn = new System.Windows.Forms.Button();
            this.HapusBtn = new System.Windows.Forms.Button();
            this.directorySearcher2 = new System.DirectoryServices.DirectorySearcher();
            this.directorySearcher3 = new System.DirectoryServices.DirectorySearcher();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CariBtn = new System.Windows.Forms.Button();
            this.LabelMsg = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // SimpanBtn
            // 
            this.SimpanBtn.Location = new System.Drawing.Point(211, 286);
            this.SimpanBtn.Name = "SimpanBtn";
            this.SimpanBtn.Size = new System.Drawing.Size(111, 46);
            this.SimpanBtn.TabIndex = 0;
            this.SimpanBtn.Text = "SIMPAN";
            this.SimpanBtn.UseVisualStyleBackColor = true;
            this.SimpanBtn.Click += new System.EventHandler(this.SimpanBtn_Click);
            // 
            // Judul
            // 
            this.Judul.AutoSize = true;
            this.Judul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.Judul.Location = new System.Drawing.Point(289, 37);
            this.Judul.Name = "Judul";
            this.Judul.Size = new System.Drawing.Size(212, 24);
            this.Judul.TabIndex = 2;
            this.Judul.Text = "DATABASE GUDANG";
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(75, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "KODE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(75, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "NAMA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(75, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "JUMLAH";
            // 
            // KodeInput
            // 
            this.KodeInput.Location = new System.Drawing.Point(174, 118);
            this.KodeInput.Name = "KodeInput";
            this.KodeInput.Size = new System.Drawing.Size(148, 20);
            this.KodeInput.TabIndex = 6;
            // 
            // NamaInput
            // 
            this.NamaInput.Location = new System.Drawing.Point(174, 156);
            this.NamaInput.Name = "NamaInput";
            this.NamaInput.Size = new System.Drawing.Size(148, 20);
            this.NamaInput.TabIndex = 7;
            // 
            // JumlahInput
            // 
            this.JumlahInput.Location = new System.Drawing.Point(174, 192);
            this.JumlahInput.Name = "JumlahInput";
            this.JumlahInput.Size = new System.Drawing.Size(148, 20);
            this.JumlahInput.TabIndex = 8;
            // 
            // EditBtn
            // 
            this.EditBtn.Location = new System.Drawing.Point(78, 358);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(111, 47);
            this.EditBtn.TabIndex = 10;
            this.EditBtn.Text = "EDIT";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // HapusBtn
            // 
            this.HapusBtn.Location = new System.Drawing.Point(211, 358);
            this.HapusBtn.Name = "HapusBtn";
            this.HapusBtn.Size = new System.Drawing.Size(111, 47);
            this.HapusBtn.TabIndex = 11;
            this.HapusBtn.Text = "HAPUS";
            this.HapusBtn.UseVisualStyleBackColor = true;
            this.HapusBtn.Click += new System.EventHandler(this.HapusBtn_Click);
            // 
            // directorySearcher2
            // 
            this.directorySearcher2.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher2.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher2.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // directorySearcher3
            // 
            this.directorySearcher3.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher3.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher3.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(439, 118);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(300, 199);
            this.dataGridView1.TabIndex = 13;
            // 
            // CariBtn
            // 
            this.CariBtn.Location = new System.Drawing.Point(78, 287);
            this.CariBtn.Name = "CariBtn";
            this.CariBtn.Size = new System.Drawing.Size(111, 46);
            this.CariBtn.TabIndex = 12;
            this.CariBtn.Text = "CARI";
            this.CariBtn.UseVisualStyleBackColor = true;
            this.CariBtn.Click += new System.EventHandler(this.CariBtn_Click);
            // 
            // LabelMsg
            // 
            this.LabelMsg.Font = new System.Drawing.Font("Fira Code Retina", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMsg.Location = new System.Drawing.Point(74, 226);
            this.LabelMsg.Name = "LabelMsg";
            this.LabelMsg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LabelMsg.Size = new System.Drawing.Size(248, 44);
            this.LabelMsg.TabIndex = 14;
            this.LabelMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LabelMsg);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.CariBtn);
            this.Controls.Add(this.HapusBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.JumlahInput);
            this.Controls.Add(this.NamaInput);
            this.Controls.Add(this.KodeInput);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Judul);
            this.Controls.Add(this.SimpanBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SimpanBtn;
        private System.Windows.Forms.Label Judul;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox KodeInput;
        private System.Windows.Forms.TextBox NamaInput;
        private System.Windows.Forms.TextBox JumlahInput;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button HapusBtn;
        private System.DirectoryServices.DirectorySearcher directorySearcher2;
        private System.DirectoryServices.DirectorySearcher directorySearcher3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button CariBtn;
        private System.Windows.Forms.Label LabelMsg;
    }
}

