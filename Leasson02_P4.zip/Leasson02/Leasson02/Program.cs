﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Program
    {
        static void Main(string[] args)
        {
            // Volume Segitiga
            // Rectangle rect = new Rectangle(10.0, 20.0);
            // double area = rect.GetArea();
            // Console.WriteLine("Area of Rectangle: {0}", rect.GetArea());

            //Segitiga segi = new Segitiga(5.0, 10.0);
            //double luas = segi.LuasSegitiga();
            //Console.WriteLine("Luas segitiga: {0}", luas);


            // Volume Tabung
            //Console.Write("Masukan  jari jari tabung: ");
            //double jariJari = Convert.ToDouble(Console.ReadLine());

            //Console.Write("Masukan tinggi tabung: ");
            //double tinggi = Convert.ToDouble(Console.ReadLine());

            //Tabung bung = new Tabung(jariJari, tinggi);
            //double volumeTabung = bung.VolumeTabung();
            //Console.WriteLine("Volume tabung: {0}", volumeTabung);


            // Volume Limas
            Limas mas = new Limas();
            mas.PanjangAlas = 5.0;
            mas.LebarAlas = 4.0;
            mas.Tinggi = 10.0;
            Console.WriteLine("Volume tabung: {0}", mas.VolumeLimas());

            Console.ReadKey();
        }
    }
}
