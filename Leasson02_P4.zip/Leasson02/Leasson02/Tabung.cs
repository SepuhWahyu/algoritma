﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Tabung
    {
        private double radius, tinggi;

        public Tabung(double j, double t)
        {
            radius = j;
            tinggi = t;
        }

        public double VolumeTabung()
        {
            return Math.PI * Math.Pow(radius, 2) * tinggi;
        }
    }
}
