﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Segitiga
    {
        private double Tinggi, Alas;

        public Segitiga(double t, double a)
        {
            Tinggi = t;
            Alas = a;
        }

        public double LuasSegitiga()
        {
            return 0.5 * Tinggi * Alas;
        }
    }
}
