﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02_A
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Masukan Nilai Length: ");
            double length = Convert.ToDouble(Console.ReadLine());
            Console.Write("Masukan Nilai Width: ");
            double width = Convert.ToDouble(Console.ReadLine());
            Console.Write("Masukan Nilai Jari-Jari: ");
            double jari2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Masukan Nilai Tinggi: ");
            double tinggi = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            Rectangle rect = new Rectangle(length, width);
            Console.WriteLine("Rectangle Area: {0}", rect.GetArea());
             
            Tabung tab = new Tabung(jari2, tinggi);
            Console.WriteLine("Volume Tabung: {0}", tab.VolumeTabung());

            Bola bola = new Bola(jari2);
            Console.WriteLine("Volume Bola: {0}", bola.VolumeBola());

            Kerucut keru = new Kerucut(jari2, tinggi);
            Console.WriteLine("Volume Kerucut: {0}", keru.VolumeKerucut());

            Console.ReadKey();
        }
    }
}
