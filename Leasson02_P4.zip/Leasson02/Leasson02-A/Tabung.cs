﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02_A
{
    class Tabung : Polygon
    {
        public Tabung(double jari2, double tinggi)
        {
            Jari2 = jari2;
            Tinggi = tinggi;
        }

        public double VolumeTabung()
        {
            return Math.PI * Math.Pow(Jari2, 2) * Tinggi;
        }
    }
}
