﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Program
    {
        static void Main(string[] args)
        {
            // Rectangle rect = new Rectangle(10.0, 20.0);
            // double area = rect.GetArea();
            // Console.WriteLine("Area of Rectangle: {0}", rect.GetArea());

            Segitiga segi = new Segitiga(5.0, 10.0);
            double luas = segi.LuasSegitiga();
            Console.WriteLine("Luas segitiga: {0}", luas);
        }
    }
}
