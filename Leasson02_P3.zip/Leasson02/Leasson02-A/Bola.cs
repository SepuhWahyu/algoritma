﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02_A
{
    class Bola : Polygon
    {
        public Bola(double jari2)
        {
            Jari2 = jari2;
        }

        public double VolumeBola()
        {
            return Math.PI * Jari2 * 4 / 3;
        }
    }
}
