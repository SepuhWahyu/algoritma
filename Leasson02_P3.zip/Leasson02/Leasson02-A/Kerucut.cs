﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02_A
{
    class Kerucut : Polygon
    {
        public Kerucut(double jari2, double tinggi)
        {
            Jari2 = jari2;
            Tinggi = tinggi;
        }

        public double VolumeKerucut()
        {
            return Math.PI * Math.Pow(Jari2, 2) * Tinggi * 1 / 3;
        }
    }
}
