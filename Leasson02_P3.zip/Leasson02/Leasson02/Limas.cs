﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leasson02
{
    class Limas
    {
        private double panjangAlas, lebarAlas, tinggi;

        public double PanjangAlas
        {
            get
            {
                return panjangAlas;

            }
            set
            {
                if (value > 0.0)
                    panjangAlas = value;
            }
        }

        public double LebarAlas
        {
            get
            {
                return lebarAlas;

            }
            set
            {
                if (value > 0.0)
                    lebarAlas = value;
            }
        }

        public double Tinggi
        {
            get
            {
                return tinggi;

            }
            set
            {
                if (value > 0.0)
                    tinggi = value;
            }
        }

        //public Limas(double p, double l, double t)
        //{
        //    panjangAlas = p;
        //    lebarAlas = l;
        //    tinggi = t;
        //}

        public double VolumeLimas()
        {
            return panjangAlas * lebarAlas * tinggi * 1 / 3;
        }
    }
}
